"""Auto-generated file, do not edit by hand. 39 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_39 = [NumberFormat(pattern='(\\d{4})(\\d{2})(\\d{2})(\\d{2})', format='\\1 \\2 \\3 \\4', leading_digits_pattern=['0(?:[13-579][2-46-8]|8[236-8])']), NumberFormat(pattern='(\\d{4})(\\d{2})(\\d{3})', format='\\1 \\2 \\3', leading_digits_pattern=['0(?:[13-579][2-46-8]|8[236-8])'])]
