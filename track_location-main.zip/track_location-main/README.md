# Track Location
Temukan Lokasi Nomor Telepon Menggunakan Python Di MAP!
<br>
<p>Source code ini hanya tujuan pendidikan saja. Saya tidak menyakiti siapa pun. Saya menggunakan perangkat saya sendiri selama menjalankan metode ini. Jadi tolong jangan gunakan metode ini untuk segala jenis kegiatan ilegal atau berbahaya. Karena peretasan adalah kejahatan, jika Anda melakukan ini maka Anda bisa masuk penjara.
Saya tidak mendukung segala jenis peretasan ilegal atau berbahaya.</p>

<h3>Installation</h3>
<p>
  Install using
  <a href="https://pypi.org/project/phonenumbers/" rel="nofollow">pip</a>
  with:
</p>
<pre>
  <code>pip install phonenumbers</code>
  <code>pip install opencage</code>
  <code>pip install folium</code>
</pre>
<p>Jangan lupa untuk mendaftar pada OpenCage Geocoding: https://opencagedata.com/ untuk mendapatkan API.</p>
